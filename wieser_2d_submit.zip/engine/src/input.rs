/*


ONLY KEYBOARD

set to specific keys function
on-key press
-- now key, then key
is_pressed -> maybe wrapper

fixed update vs update
even if not ready

update-> as soon as possible
keep track of time between frames 

*/
